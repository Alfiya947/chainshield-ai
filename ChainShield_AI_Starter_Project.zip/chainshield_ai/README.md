# ChainShield AI

Agentic transaction investigation and controlled risk-resolution prototype.

## Features
- Adaptive-style investigation planning based on transaction details
- Role and refund-limit checks
- Duplicate and transaction-history investigation tools
- Relationship graph in the Streamlit interface
- Explainable decision and evidence report
- Human approval gate for simulated actions
- Closed-loop verification of simulated transaction state
- Persistent local SQLite investigation and audit records
- Built-in scenario test centre

## Run locally

Python 3.10+ recommended.

```bash
python -m pip install -r requirements.txt
python -m streamlit run app.py --server.address 0.0.0.0
```

Open the Streamlit preview on port 8501 in Codespaces.

## Run tests

```bash
python test_agent.py
```

## Project files
- `app.py`: Streamlit interface
- `agent_engine.py`: investigation planner, tools, decision rules, and simulated action verification
- `database.py`: SQLite persistence for investigations and audit events
- `test_agent.py`: automated scenario tests
- `requirements.txt`: Python dependencies

## Important limitations
This is a local prototype using synthetic data. It does not connect to banks or execute real financial transactions. The planner is deterministic and adaptive-style; a language-model-driven planner is not yet included. Mandatory policies are enforced in Python and must not be delegated to an LLM.
