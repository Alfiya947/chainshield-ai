import json
from datetime import datetime, timezone

import pandas as pd
import streamlit as st

from agent_engine import DEFAULT_POLICY, investigate_transaction, execute_simulated_action
from database import init_db, save_report, list_investigations, list_audit_events, clear_local_demo_data

st.set_page_config(
    page_title="ChainShield AI",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded",
)

init_db()

st.markdown("""
<style>
:root { --cs-bg: #0b1220; --cs-card: #111c2e; --cs-line: #263750; --cs-text: #e8eef8; --cs-muted: #9aabc2; --cs-accent: #40d6bd; }
.stApp { background: linear-gradient(135deg, #09111f 0%, #0d1728 55%, #101b2e 100%); color: var(--cs-text); }
[data-testid="stSidebar"] { background: #0a1220; border-right: 1px solid #24344b; }
h1, h2, h3 { color: #f2f6fc !important; letter-spacing: -0.02em; }
p, label, span, div { }
.cs-kicker { color: #40d6bd; text-transform: uppercase; letter-spacing: .15em; font-size: .74rem; font-weight: 800; }
.cs-sub { color: #9aabc2; font-size: 1rem; }
.cs-card { background: rgba(17,28,46,.88); border: 1px solid #263750; padding: 1rem 1.15rem; border-radius: 16px; min-height: 108px; }
.cs-label { color: #9aabc2; font-size: .82rem; margin-bottom: .35rem; }
.cs-value { color: #f4f7fb; font-size: 1.65rem; font-weight: 800; }
.cs-note { color: #9aabc2; font-size: .82rem; }
div[data-testid="stMetric"] { background: rgba(17,28,46,.8); border: 1px solid #263750; padding: 13px 15px; border-radius: 14px; }
div[data-testid="stMetricLabel"] { color: #9aabc2; }
div[data-testid="stMetricValue"] { color: #f4f7fb; }
.stButton > button { border-radius: 10px; border: 1px solid #3a526e; font-weight: 700; }
.stButton > button[kind="primary"] { background: #31bfa9; border-color: #31bfa9; color: #06151b; }
hr { border-color: #263750; }
[data-testid="stDataFrame"] { border: 1px solid #263750; border-radius: 10px; overflow: hidden; }
</style>
""", unsafe_allow_html=True)

POLICY = dict(DEFAULT_POLICY)
if "reports" not in st.session_state:
    st.session_state.reports = []
if "active_report" not in st.session_state:
    st.session_state.active_report = None

SAMPLE_HISTORY = [
    {"transaction_id": "TX-1007", "original_transaction_id": "ORD-778", "account_ref": "AC-201", "amount": 4500, "type": "refund", "status": "COMPLETED"},
    {"transaction_id": "TX-1011", "original_transaction_id": "ORD-778", "account_ref": "AC-201", "amount": 4500, "type": "refund", "status": "COMPLETED"},
    {"transaction_id": "TX-1015", "original_transaction_id": "ORD-991", "account_ref": "AC-338", "amount": 2100, "type": "refund", "status": "COMPLETED"},
    {"transaction_id": "TX-1020", "original_transaction_id": "ORD-110", "account_ref": "AC-410", "amount": 1800, "type": "refund", "status": "COMPLETED"},
    {"transaction_id": "TX-1024", "original_transaction_id": "ORD-992", "account_ref": "AC-338", "amount": 1200, "type": "refund", "status": "COMPLETED"},
]

def badge(text, color):
    st.markdown(
        f'<span style="display:inline-block;padding:5px 10px;border-radius:999px;'
        f'background:{color}20;border:1px solid {color}88;color:{color};font-weight:800;font-size:.78rem;">{text}</span>',
        unsafe_allow_html=True
    )

def status_color(status):
    return {"ALLOW": "#40d6bd", "ESCALATE": "#f6bd60", "BLOCK": "#ff6b7a",
            "VERIFIED": "#40d6bd", "FAILED": "#ff6b7a"}.get(status, "#9aabc2")

def save_report_once(report):
    if not report:
        return
    saved_ids = st.session_state.get("saved_case_ids", set())
    if report.get("case_id") not in saved_ids:
        save_report(report)
        saved_ids.add(report.get("case_id"))
        st.session_state.saved_case_ids = saved_ids

with st.sidebar:
    st.markdown('<div class="cs-kicker">Enterprise risk intelligence</div>', unsafe_allow_html=True)
    st.title("🛡️ ChainShield AI")
    st.caption("Agentic transaction investigation")
    page = st.radio(
        "NAVIGATION",
        ["Overview", "Investigation Lab", "Test Centre", "Audit Trail"],
        label_visibility="visible"
    )
    st.divider()
    st.markdown("**Active policy**")
    st.metric("Refund threshold", f"₹{POLICY['refund_limit']:,.0f}")
    st.caption("Allowed roles: support_agent, finance_manager")
    st.caption("Prototype mode · Synthetic data only")
    st.divider()
    st.caption("Agent plans and investigates. Deterministic rules control financial decisions.")

if page == "Overview":
    st.markdown('<div class="cs-kicker">Transaction intelligence platform</div>', unsafe_allow_html=True)
    st.title("Investigate risk. Explain decisions. Verify outcomes.")
    st.markdown('<div class="cs-sub">ChainShield AI coordinates transaction checks, evidence gathering, approval, and post-action verification in one auditable workflow.</div>', unsafe_allow_html=True)
    st.write("")
    saved = list_investigations(500)
    total = len(saved)
    escalated = sum(1 for r in saved if r["decision"] == "ESCALATE")
    blocked = sum(1 for r in saved if r["decision"] == "BLOCK")
    verified = sum(1 for r in saved if r["verification_status"] == "VERIFIED")
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Investigations saved", total)
    c2.metric("Escalated cases", escalated)
    c3.metric("Blocked cases", blocked)
    c4.metric("Verified outcomes", verified)
    st.write("")
    st.subheader("How ChainShield works")
    steps = st.columns(5)
    for col, number, title, desc in zip(
        steps,
        ["01", "02", "03", "04", "05"],
        ["Screen", "Investigate", "Explain", "Approve", "Verify"],
        [
            "Apply deterministic policy checks.",
            "Select tools based on case evidence.",
            "Show reasons and supporting records.",
            "Gate consequential actions with approval.",
            "Read the final state and confirm the result.",
        ],
    ):
        with col:
            st.markdown(
                f'<div class="cs-card"><div class="cs-kicker">{number}</div>'
                f'<h3 style="margin:.45rem 0">{title}</h3><div class="cs-note">{desc}</div></div>',
                unsafe_allow_html=True
            )
    st.write("")
    st.subheader("Try a scenario")
    s1, s2, s3 = st.columns(3)
    with s1:
        st.markdown("**High-value refund**")
        st.caption("Refund above ₹20,000; approval review required.")
        if st.button("Open high-value case", use_container_width=True):
            st.session_state.prefill_scenario = "High-value refund"
            st.rerun()
    with s2:
        st.markdown("**Related refund activity**")
        st.caption("Multiple records linked to one account.")
        if st.button("Open related-activity case", use_container_width=True):
            st.session_state.prefill_scenario = "Related refund activity"
            st.rerun()
    with s3:
        st.markdown("**Unauthorized role**")
        st.caption("Role is outside the configured allowed list.")
        if st.button("Open unauthorized case", use_container_width=True):
            st.session_state.prefill_scenario = "Unauthorized role"
            st.rerun()
    st.info("This prototype uses synthetic transaction records. It does not connect to banks or execute real payments.")

elif page == "Investigation Lab":
    st.markdown('<div class="cs-kicker">Live sandbox</div>', unsafe_allow_html=True)
    st.title("Investigation Lab")
    st.markdown('<div class="cs-sub">Configure a transaction, run the agent, inspect its evidence, and test a human-approved simulated action.</div>', unsafe_allow_html=True)

    scenario_defaults = {
        "Custom transaction": {"transaction_id": "TX-1042", "original_transaction_id": "ORD-778", "account_ref": "AC-201", "amount": 28000.0, "employee_role": "support_agent", "risk_hint": "none"},
        "High-value refund": {"transaction_id": "TX-1042", "original_transaction_id": "ORD-778", "account_ref": "AC-201", "amount": 28000.0, "employee_role": "support_agent", "risk_hint": "none"},
        "Related refund activity": {"transaction_id": "TX-2041", "original_transaction_id": "ORD-778", "account_ref": "AC-201", "amount": 4500.0, "employee_role": "support_agent", "risk_hint": "repeated_activity"},
        "Unauthorized role": {"transaction_id": "TX-3099", "original_transaction_id": "ORD-880", "account_ref": "AC-512", "amount": 7200.0, "employee_role": "intern", "risk_hint": "none"},
        "Clean transaction": {"transaction_id": "TX-4010", "original_transaction_id": "ORD-401", "account_ref": "AC-610", "amount": 3200.0, "employee_role": "support_agent", "risk_hint": "none"},
        "Duplicate request": {"transaction_id": "TX-1007", "original_transaction_id": "ORD-778", "account_ref": "AC-201", "amount": 4500.0, "employee_role": "finance_manager", "risk_hint": "none"},
    }
    if "prefill_scenario" in st.session_state:
        st.session_state.scenario_choice = st.session_state.pop("prefill_scenario")
    if "scenario_choice" not in st.session_state:
        st.session_state.scenario_choice = "High-value refund"

    scenario = st.selectbox("Choose a starting scenario", list(scenario_defaults), key="scenario_choice")
    defaults = scenario_defaults[scenario]
    with st.form("transaction_form"):
        a, b, c = st.columns(3)
        transaction_id = a.text_input("Transaction ID", defaults["transaction_id"])
        original_id = b.text_input("Original order / transaction ID", defaults["original_transaction_id"])
        account_ref = c.text_input("Account reference", defaults["account_ref"])
        d, e, f = st.columns(3)
        amount = d.number_input("Refund amount (₹)", min_value=0.0, value=float(defaults["amount"]), step=500.0)
        role = e.selectbox("Employee role", ["support_agent", "finance_manager", "intern", "guest", "unknown"],
                           index=["support_agent", "finance_manager", "intern", "guest", "unknown"].index(defaults["employee_role"]))
        risk_hint = f.selectbox("Investigation hint", ["none", "repeated_activity", "related_records"],
                                index=["none", "repeated_activity", "related_records"].index(defaults["risk_hint"]))
        include_duplicates = st.checkbox("Run duplicate-record check", value=True)
        run = st.form_submit_button("🛡️ Run investigation", type="primary", use_container_width=True)

    if run:
        transaction = {
            "transaction_id": transaction_id.strip() or "UNKNOWN",
            "original_transaction_id": original_id.strip(),
            "account_ref": account_ref.strip(),
            "amount": float(amount),
            "employee_role": role,
            "risk_hint": risk_hint,
            "check_duplicates": include_duplicates,
            "status": "PENDING",
            "type": "refund",
        }
        report = investigate_transaction(transaction, SAMPLE_HISTORY, POLICY)
        report["audit_events"] = [{
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "event": "investigation_completed",
            "detail": f"Investigation completed with decision {report['decision']}; tools: {', '.join(report['plan'])}.",
        }]
        st.session_state.active_report = report
        st.session_state.action_approved = False

    report = st.session_state.active_report
    if report:
        st.divider()
        st.subheader("Investigation result")
        top1, top2, top3, top4 = st.columns(4)
        top1.metric("Case ID", report["case_id"])
        top2.metric("Transaction", report["transaction_id"])
        top3.metric("Decision", report["decision"])
        top4.metric("Tools used", len(report["tool_results"]))
        badge(report["decision"], status_color(report["decision"]))
        st.markdown(f"**Recommended action:** {report['recommended_action']}")
        for reason in report["reasons"]:
            st.write(f"• {reason}")

        tab1, tab2, tab3 = st.tabs(["Evidence & tools", "Transaction graph", "Action & verification"])
        with tab1:
            st.markdown("#### Agent investigation plan")
            st.write(" → ".join(report["plan"]))
            for item in report["tool_results"]:
                with st.expander(f"{item['tool']} · {item['status']}", expanded=True):
                    st.write(item["summary"])
                    st.json(item["evidence"])
        with tab2:
            st.markdown("#### Relationship view")
            tx = report["transaction"]
            related = [x for x in SAMPLE_HISTORY if x.get("account_ref") == tx.get("account_ref")]
            dot = ['digraph G { rankdir=LR; bgcolor="transparent"; node [shape=box, style="rounded,filled", fontname="Arial", color="#38516f", fontcolor="#eaf2ff"]; edge [color="#6984a6"];']
            dot.append(f'"{tx["transaction_id"]}" [label="{tx["transaction_id"]}\\nCurrent case", fillcolor="#155e75"];')
            for i, item in enumerate(related[:6]):
                node_id = f'hist_{i}'
                label = f'{item.get("transaction_id")}\\n₹{float(item.get("amount", 0)):,.0f}'
                dot.append(f'"{node_id}" [label="{label}", fillcolor="#172b43"];')
                dot.append(f'"{tx["transaction_id"]}" -> "{node_id}" [label="same account"];')
            if not related:
                dot.append('"note" [label="No matching account records", fillcolor="#172b43"];')
                dot.append(f'"{tx["transaction_id"]}" -> "note";')
            dot.append("}")
            st.graphviz_chart("\n".join(dot), use_container_width=True)
            st.caption("Graph links indicate shared sample attributes, not proof of fraud.")
        with tab3:
            st.markdown("#### Human approval gate")
            st.write("All actions in this demo affect simulated local data only.")
            if report["decision"] == "BLOCK":
                action_options = ["reject", "mark_for_review"]
            elif report["decision"] == "ESCALATE":
                action_options = ["mark_for_review", "reject"]
            else:
                action_options = ["allow", "mark_for_review"]
            action = st.selectbox("Simulated action", action_options, index=0, key=f"sim_action_{report['case_id']}")
            approved = st.checkbox("I approve this simulated action", key="approve_action")
            if st.button("Execute and verify", type="primary", disabled=not approved, use_container_width=True):
                updated = execute_simulated_action(report, action=action, approved=True)
                updated.setdefault("audit_events", []).append({
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    "event": "human_approval",
                    "detail": f"User approved simulated action '{action}'.",
                })
                st.session_state.active_report = updated
                save_report_once(updated)
                st.rerun()
            current = st.session_state.active_report
            x, y, z = st.columns(3)
            x.metric("Action status", current.get("action_status", "NOT_EXECUTED"))
            y.metric("Verification", current.get("verification_status", "NOT_APPLICABLE"))
            z.metric("Final simulated status", current.get("transaction", {}).get("status", "PENDING"))
            if current.get("verified"):
                st.success("Verified: the simulated transaction state matches the expected result.")
            elif current.get("action_status") == "EXECUTED":
                st.error("The action did not pass verification. Keep the case open for review.")
            else:
                st.info("No action has been verified yet. Approve and execute a simulated action to test the verification loop.")

elif page == "Test Centre":
    st.markdown('<div class="cs-kicker">Repeatable scenario testing</div>', unsafe_allow_html=True)
    st.title("Test Centre")
    st.markdown('<div class="cs-sub">Run a small, repeatable set of synthetic cases to inspect policy outcomes and tool behavior.</div>', unsafe_allow_html=True)
    test_cases = [
        {"name": "Clean transaction", "transaction": {"transaction_id": "T-001", "original_transaction_id": "O-001", "account_ref": "A-001", "amount": 3200, "employee_role": "support_agent", "risk_hint": "none", "check_duplicates": True}, "expected": "ALLOW"},
        {"name": "Above refund limit", "transaction": {"transaction_id": "T-002", "original_transaction_id": "O-002", "account_ref": "A-002", "amount": 35000, "employee_role": "support_agent", "risk_hint": "none", "check_duplicates": True}, "expected": "ESCALATE"},
        {"name": "Unauthorized role", "transaction": {"transaction_id": "T-003", "original_transaction_id": "O-003", "account_ref": "A-003", "amount": 1000, "employee_role": "intern", "risk_hint": "none", "check_duplicates": True}, "expected": "BLOCK"},
        {"name": "Repeated activity", "transaction": {"transaction_id": "T-004", "original_transaction_id": "O-778", "account_ref": "AC-201", "amount": 4500, "employee_role": "support_agent", "risk_hint": "repeated_activity", "check_duplicates": True}, "expected": "ESCALATE"},
    ]
    if st.button("Run all tests", type="primary"):
        rows = []
        for case in test_cases:
            result = investigate_transaction(case["transaction"], SAMPLE_HISTORY, POLICY)
            rows.append({
                "Test": case["name"],
                "Expected": case["expected"],
                "Actual": result["decision"],
                "Result": "PASS" if result["decision"] == case["expected"] else "FAIL",
                "Tools used": ", ".join(result["plan"]),
            })
        st.session_state.test_results = rows
    if st.session_state.get("test_results"):
        df = pd.DataFrame(st.session_state.test_results)
        st.dataframe(df, use_container_width=True, hide_index=True)
        passed = sum(1 for row in st.session_state.test_results if row["Result"] == "PASS")
        st.metric("Scenario tests passed", f"{passed}/{len(st.session_state.test_results)}")
        if passed == len(st.session_state.test_results):
            st.success("All scenario expectations passed.")
        else:
            st.warning("Review failed scenarios before presenting the prototype.")
    else:
        st.info("Click **Run all tests** to execute the four built-in scenarios.")
    with st.expander("What these tests do and do not prove"):
        st.write("These are deterministic checks against synthetic scenarios. They help validate expected prototype behavior; they do not establish real-world fraud-detection accuracy.")

elif page == "Audit Trail":
    st.markdown('<div class="cs-kicker">Traceability & accountability</div>', unsafe_allow_html=True)
    st.title("Audit Trail")
    st.markdown('<div class="cs-sub">Persisted investigation records and action events from this local prototype.</div>', unsafe_allow_html=True)
    records = list_investigations(300)
    if records:
        view = pd.DataFrame([{
            "Case ID": r["case_id"],
            "Transaction": r["transaction_id"],
            "Decision": r["decision"],
            "Action": r["action_status"] or "NOT_EXECUTED",
            "Verification": r["verification_status"] or "NOT_APPLICABLE",
            "Created": r["created_at"],
        } for r in records])
        st.dataframe(view, use_container_width=True, hide_index=True)
        selected = st.selectbox("Inspect a saved case", [r["case_id"] for r in records])
        selected_record = next((r for r in records if r["case_id"] == selected), None)
        if selected_record:
            st.json(json.loads(selected_record["report_json"]))
    else:
        st.info("No saved investigations yet. Run a case in the Investigation Lab and execute an approved simulated action to create a record.")
    st.divider()
    st.subheader("Audit events")
    events = list_audit_events(300)
    if events:
        st.dataframe(pd.DataFrame([{
            "Case ID": e["case_id"], "Timestamp": e["timestamp"], "Event": e["event"], "Detail": e["detail"]
        } for e in events]), use_container_width=True, hide_index=True)
    else:
        st.caption("No action events recorded yet.")
    with st.expander("Clear local demo records"):
        st.warning("This permanently clears the local SQLite records created by this prototype.")
        if st.button("Clear audit and investigation records"):
            clear_local_demo_data()
            st.session_state.saved_case_ids = set()
            st.success("Local demo records cleared.")
            st.rerun()
