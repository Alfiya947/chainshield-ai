import unittest
from agent_engine import DEFAULT_POLICY, investigate_transaction, execute_simulated_action

HISTORY = [
    {"transaction_id": "TX-1007", "original_transaction_id": "ORD-778", "account_ref": "AC-201", "amount": 4500, "type": "refund"},
    {"transaction_id": "TX-1011", "original_transaction_id": "ORD-778", "account_ref": "AC-201", "amount": 4500, "type": "refund"},
    {"transaction_id": "TX-1024", "original_transaction_id": "ORD-992", "account_ref": "AC-338", "amount": 1200, "type": "refund"},
]

class ChainShieldTests(unittest.TestCase):
    def test_clean_transaction_allowed(self):
        tx = {"transaction_id": "T-1", "original_transaction_id": "O-1", "account_ref": "A-1", "amount": 3200, "employee_role": "support_agent", "check_duplicates": True}
        report = investigate_transaction(tx, HISTORY, DEFAULT_POLICY)
        self.assertEqual(report["decision"], "ALLOW")

    def test_high_value_escalated(self):
        tx = {"transaction_id": "T-2", "original_transaction_id": "O-2", "account_ref": "A-2", "amount": 35000, "employee_role": "support_agent", "check_duplicates": True}
        report = investigate_transaction(tx, HISTORY, DEFAULT_POLICY)
        self.assertEqual(report["decision"], "ESCALATE")

    def test_unauthorized_role_blocked(self):
        tx = {"transaction_id": "T-3", "original_transaction_id": "O-3", "account_ref": "A-3", "amount": 1000, "employee_role": "intern", "check_duplicates": True}
        report = investigate_transaction(tx, HISTORY, DEFAULT_POLICY)
        self.assertEqual(report["decision"], "BLOCK")

    def test_duplicate_escalated(self):
        tx = {"transaction_id": "T-4", "original_transaction_id": "ORD-778", "account_ref": "AC-201", "amount": 4500, "employee_role": "support_agent", "check_duplicates": True}
        report = investigate_transaction(tx, HISTORY, DEFAULT_POLICY)
        self.assertEqual(report["decision"], "ESCALATE")

    def test_approved_action_is_verified(self):
        tx = {"transaction_id": "T-5", "original_transaction_id": "O-5", "account_ref": "A-5", "amount": 35000, "employee_role": "support_agent", "check_duplicates": True}
        report = investigate_transaction(tx, HISTORY, DEFAULT_POLICY)
        updated = execute_simulated_action(report, "mark_for_review", approved=True)
        self.assertEqual(updated["verification_status"], "VERIFIED")
        self.assertTrue(updated["verified"])

if __name__ == "__main__":
    unittest.main(verbosity=2)
