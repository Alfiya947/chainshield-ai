from __future__ import annotations
import json
import sqlite3
from pathlib import Path
from datetime import datetime, timezone

DB_PATH = Path(__file__).with_name("chainshield.db")

def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with get_connection() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS investigations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                case_id TEXT NOT NULL,
                transaction_id TEXT NOT NULL,
                decision TEXT NOT NULL,
                action_status TEXT,
                verification_status TEXT,
                created_at TEXT NOT NULL,
                report_json TEXT NOT NULL
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS audit_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                case_id TEXT NOT NULL,
                timestamp TEXT NOT NULL,
                event TEXT NOT NULL,
                detail TEXT NOT NULL
            )
        """)
        conn.commit()

def save_report(report: dict):
    init_db()
    with get_connection() as conn:
        conn.execute("""
            INSERT INTO investigations
            (case_id, transaction_id, decision, action_status, verification_status, created_at, report_json)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (
            report.get("case_id", ""),
            report.get("transaction_id", ""),
            report.get("decision", ""),
            report.get("action_status", ""),
            report.get("verification_status", ""),
            report.get("started_at", datetime.now(timezone.utc).isoformat()),
            json.dumps(report, ensure_ascii=False, default=str),
        ))
        for event in report.get("audit_events", []):
            conn.execute("""
                INSERT INTO audit_events (case_id, timestamp, event, detail)
                VALUES (?, ?, ?, ?)
            """, (
                report.get("case_id", ""),
                event.get("timestamp", datetime.now(timezone.utc).isoformat()),
                event.get("event", "investigation"),
                event.get("detail", ""),
            ))
        conn.commit()

def list_investigations(limit: int = 100):
    init_db()
    with get_connection() as conn:
        rows = conn.execute("""
            SELECT id, case_id, transaction_id, decision, action_status,
                   verification_status, created_at, report_json
            FROM investigations ORDER BY id DESC LIMIT ?
        """, (limit,)).fetchall()
    return [dict(row) for row in rows]

def list_audit_events(limit: int = 300):
    init_db()
    with get_connection() as conn:
        rows = conn.execute("""
            SELECT id, case_id, timestamp, event, detail
            FROM audit_events ORDER BY id DESC LIMIT ?
        """, (limit,)).fetchall()
    return [dict(row) for row in rows]

def clear_local_demo_data():
    init_db()
    with get_connection() as conn:
        conn.execute("DELETE FROM investigations")
        conn.execute("DELETE FROM audit_events")
        conn.commit()
