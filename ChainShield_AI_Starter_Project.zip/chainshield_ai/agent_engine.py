from __future__ import annotations

from datetime import datetime, timezone
from typing import Any
import uuid

DEFAULT_POLICY = {
    "refund_limit": 20000.0,
    "allowed_roles": ["support_agent", "finance_manager"],
    "require_approval_above_limit": True,
}

def _money(value: Any) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0

def check_employee_role(role: str, policy: dict | None = None) -> dict:
    policy = policy or DEFAULT_POLICY
    allowed = role in policy["allowed_roles"]
    return {
        "tool": "check_employee_role",
        "status": "PASS" if allowed else "FAIL",
        "summary": f"Role '{role}' is {'authorized' if allowed else 'not authorized'} for refund processing.",
        "evidence": {"role": role, "allowed_roles": list(policy["allowed_roles"]), "authorized": allowed},
    }

def check_refund_limit(amount: float, policy: dict | None = None) -> dict:
    policy = policy or DEFAULT_POLICY
    limit = _money(policy["refund_limit"])
    amount = _money(amount)
    within = amount <= limit
    return {
        "tool": "check_refund_limit",
        "status": "PASS" if within else "REVIEW",
        "summary": f"Refund of ₹{amount:,.2f} is {'within' if within else 'above'} the configured ₹{limit:,.2f} threshold.",
        "evidence": {"refund_amount": amount, "refund_limit": limit, "within_limit": within},
    }

def detect_duplicate_transaction(transaction: dict, history: list[dict]) -> dict:
    tx_id = str(transaction.get("transaction_id", "")).strip()
    original_id = str(transaction.get("original_transaction_id", "")).strip()
    duplicates = []
    for item in history:
        item_id = str(item.get("transaction_id", "")).strip()
        if tx_id and item_id == tx_id:
            duplicates.append(item)
        elif original_id and str(item.get("original_transaction_id", "")).strip() == original_id:
            duplicates.append(item)
    return {
        "tool": "detect_duplicate_transaction",
        "status": "REVIEW" if duplicates else "PASS",
        "summary": f"Found {len(duplicates)} potentially duplicate or related record(s)." if duplicates else "No matching duplicate identifier found.",
        "evidence": {"match_count": len(duplicates), "matches": duplicates[:5]},
    }

def inspect_transaction_history(transaction: dict, history: list[dict]) -> dict:
    account = str(transaction.get("account_ref", "")).strip().lower()
    related = [
        item for item in history
        if account and str(item.get("account_ref", "")).strip().lower() == account
        and str(item.get("transaction_id", "")) != str(transaction.get("transaction_id", ""))
    ]
    refund_count = sum(1 for item in related if str(item.get("type", "refund")).lower() == "refund")
    suspicious = len(related) >= 2 or refund_count >= 2
    return {
        "tool": "inspect_transaction_history",
        "status": "REVIEW" if suspicious else "PASS",
        "summary": f"Found {len(related)} related historical record(s); {refund_count} marked as refunds.",
        "evidence": {"related_count": len(related), "refund_count": refund_count, "related_records": related[:8]},
    }

def plan_investigation(transaction: dict, policy: dict | None = None) -> list[str]:
    """Select tools based on initial transaction attributes."""
    policy = policy or DEFAULT_POLICY
    plan = ["check_employee_role", "check_refund_limit"]
    amount = _money(transaction.get("amount"))
    if amount > _money(policy["refund_limit"]):
        plan.append("inspect_transaction_history")
    if transaction.get("original_transaction_id") or transaction.get("check_duplicates", True):
        plan.append("detect_duplicate_transaction")
    # History inspection is useful for every case with an account reference, but only
    # selected early for high-value or explicitly suspicious cases.
    if transaction.get("risk_hint") in {"repeated_activity", "related_records"}:
        if "inspect_transaction_history" not in plan:
            plan.append("inspect_transaction_history")
    return plan

TOOL_REGISTRY = {
    "check_employee_role": lambda tx, history, policy: check_employee_role(str(tx.get("employee_role", "")), policy),
    "check_refund_limit": lambda tx, history, policy: check_refund_limit(_money(tx.get("amount")), policy),
    "inspect_transaction_history": lambda tx, history, policy: inspect_transaction_history(tx, history),
    "detect_duplicate_transaction": lambda tx, history, policy: detect_duplicate_transaction(tx, history),
}

def investigate_transaction(
    transaction: dict,
    history: list[dict] | None = None,
    policy: dict | None = None,
) -> dict:
    """Run a controlled, adaptive-style investigation over synthetic/local records.

    The planner is deterministic in this prototype. Mandatory policy decisions are
    always computed by code rather than delegated to a language model.
    """
    history = history or []
    policy = policy or DEFAULT_POLICY
    case_id = f"CS-{uuid.uuid4().hex[:8].upper()}"
    started = datetime.now(timezone.utc).isoformat()
    plan = plan_investigation(transaction, policy)
    results = []

    for tool_name in plan:
        tool = TOOL_REGISTRY.get(tool_name)
        if tool:
            results.append(tool(transaction, history, policy))

    by_tool = {r["tool"]: r for r in results}
    role_result = by_tool.get("check_employee_role", {})
    limit_result = by_tool.get("check_refund_limit", {})
    duplicate_result = by_tool.get("detect_duplicate_transaction", {})
    history_result = by_tool.get("inspect_transaction_history", {})

    reasons = []
    if role_result.get("status") == "FAIL":
        decision = "BLOCK"
        reasons.append("The employee role is not in the configured allowed-role list.")
    else:
        needs_review = False
        if limit_result.get("status") == "REVIEW":
            needs_review = True
            reasons.append("The refund exceeds the configured threshold and requires review.")
        if duplicate_result.get("status") == "REVIEW":
            needs_review = True
            reasons.append("A duplicate or related transaction record was found.")
        if history_result.get("status") == "REVIEW":
            needs_review = True
            reasons.append("Transaction history contains repeated related activity.")
        if needs_review:
            decision = "ESCALATE"
        else:
            decision = "ALLOW"
            reasons.append("The executed checks did not identify a configured policy violation.")

    if decision == "BLOCK":
        recommended_action = "Reject the request under the configured role policy"
    elif decision == "ESCALATE":
        recommended_action = "Send the case for authorized human review"
    else:
        recommended_action = "Allow processing under the configured policy"

    report = {
        "case_id": case_id,
        "transaction_id": str(transaction.get("transaction_id", "UNKNOWN")),
        "started_at": started,
        "transaction": transaction.copy(),
        "plan": plan,
        "tool_results": results,
        "decision": decision,
        "reasons": reasons,
        "recommended_action": recommended_action,
        "requires_human_approval": decision in {"BLOCK", "ESCALATE"},
        "investigation_complete": True,
        "action_status": "NOT_EXECUTED",
        "verification_status": "NOT_APPLICABLE",
        "verified": False,
    }
    return report

def execute_simulated_action(report: dict, action: str = "mark_for_review", approved: bool = False) -> dict:
    """Apply an approved action to the report's simulated transaction state and verify it."""
    updated = dict(report)
    updated["transaction"] = dict(report.get("transaction", {}))
    updated["audit_events"] = list(report.get("audit_events", []))

    if not approved:
        updated["action_status"] = "NOT_EXECUTED"
        updated["verification_status"] = "APPROVAL_REQUIRED"
        updated["verified"] = False
        updated["audit_events"].append({
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "event": "action_not_executed",
            "detail": "No approval was provided; simulated action was not executed.",
        })
        return updated

    if action == "mark_for_review":
        updated["transaction"]["status"] = "UNDER_REVIEW"
        expected = "UNDER_REVIEW"
    elif action == "reject":
        updated["transaction"]["status"] = "REJECTED"
        expected = "REJECTED"
    elif action == "allow":
        updated["transaction"]["status"] = "APPROVED"
        expected = "APPROVED"
    else:
        updated["action_status"] = "FAILED"
        updated["verification_status"] = "UNKNOWN_ACTION"
        updated["verified"] = False
        return updated

    updated["action_status"] = "EXECUTED"
    actual = updated["transaction"].get("status")
    updated["verification_status"] = "VERIFIED" if actual == expected else "FAILED"
    updated["verified"] = actual == expected
    updated["audit_events"].append({
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "event": "simulated_action_executed",
        "detail": f"Action '{action}' set simulated status to {actual}.",
    })
    updated["audit_events"].append({
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "event": "outcome_verification",
        "detail": f"Expected {expected}; observed {actual}; verification={updated['verification_status']}.",
    })
    return updated
